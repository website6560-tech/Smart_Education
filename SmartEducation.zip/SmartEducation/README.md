# Smart Education — Android Starter Project

এই ZIP-এ Smart Education-এর একটি Android WebView ভিত্তিক starter/prototype project আছে।

## গুরুত্বপূর্ণ
- `app/src/main/assets/background.webp` = ব্যবহারকারীর দেওয়া মূল ছবি; অ্যাপের সব screen-এর consistent background হিসেবে ব্যবহার করা হয়েছে।
- HSC Question Bank, Master Plan, Topic Notes, AI Assistant, Quiz, Search, Study Routine, Customization এবং About/আমার পরিচয় screen-এর UI আছে।
- প্রশ্ন/উত্তরের পূর্ণ ডেটাবেস এই starter-এ sample structure হিসেবে রাখা হয়নি; বাস্তব প্রশ্ন যোগ করার আগে বোর্ড/বছর/উত্তর যাচাই করা প্রয়োজন।
- AI Assistant-এ production API key সরাসরি APK-তে রাখা যাবে না; নিরাপদ backend/API proxy ব্যবহার করা উচিত।

## Android Studio
1. Android Studio খুলুন।
2. `SmartEducation` folder Open করুন।
3. Gradle sync শেষ হতে দিন।
4. একটি Android device/emulator নির্বাচন করুন।
5. Run চাপুন।

Package: `com.smarteducation.app`
Version: `1.0.0`
